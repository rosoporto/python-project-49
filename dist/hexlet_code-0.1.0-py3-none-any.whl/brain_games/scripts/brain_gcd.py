#!/usr/bin/env python3
from brain_games.games.gcd import run_even_game


def main():
    run_even_game()


if __name__ == "__main__":
    main()
