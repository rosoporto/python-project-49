### Hexlet tests and linter status:
[![Actions Status](https://github.com/rosoporto/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/rosoporto/python-project-49/actions) [![Maintainability](https://api.codeclimate.com/v1/badges/314620f7db86e182dcb6/maintainability)](https://codeclimate.com/github/rosoporto/python-project-49/maintainability)

### Видео демонстрации игры «Проверка на чётность»
[![asciicast](https://asciinema.org/a/4nq3t0viFgMHYyJHtSfY8zeBK.svg)](https://asciinema.org/a/4nq3t0viFgMHYyJHtSfY8zeBK)

### Видео демонстрации игры «Калькулятор»
[![asciicast](https://asciinema.org/a/636577.svg)](https://asciinema.org/a/636577)
